//
//  JFCityCollectionViewCell.h
//  JFFootball
//
//  Created by 张志峰 on 2016/11/21.
//  Copyright © 2016年 zhifenx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JFCityCollectionViewCell : UICollectionViewCell

@property (nonatomic, copy) NSString *title;


@end
